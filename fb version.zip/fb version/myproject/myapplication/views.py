from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.models import User, auth
from .models import *
import requests
import time
import pytz          #<---------python timezone



# Create your views here.
# def index(request):
#     return render(request, 'index.html')

def apphome(request):
    return render(request, 'apphome.html')

def home(request):
    return render(request, 'home.html')

def signup(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        if password1 == password2:
            if User.objects.filter(username=username).exists():
                messages.info(request, "username already taken")
                return redirect('signup')
            else:
                user = User.objects.create_user(username=username, email=email, password=password1)
                user.save()
                messages.info(request, "user created successfully")
                return render(request, 'login.html')
        else:
            messages.info(request, "password doesnt match")
            return render(request, 'signup.html')
    else:
        return render(request, 'signup.html')

def login(request):
    if request.method == 'POST':
        username= request.POST.get('username')
        password= request.POST.get('password')
        user= auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request,user)
            if Fbuser.objects.filter(user=request.user).exists():
                return render(request, 'home.html')
            else:
                return redirect('fbconnect')
        else:
            messages.info(request, "invalid credentials....")
            return redirect('login')
    else:
        return render(request, 'login.html')

def fbconnect(request):
    if request.method == 'POST':
        accesstoken = request.POST.get('accesstoken')
        pageid = request.POST.get('pageid')
        appid = request.POST.get('appid')
        submit = Fbuser.objects.create(user=request.user, accesstoken=accesstoken, page=pageid, app=appid)
        submit.save()
        messages.info(request, "Submit successfully!")
        return render(request, 'home.html')
    else:
        return render(request, 'fbconnect.html')

def publish(request):
    if request.method == 'POST':
        message = request.POST.get('message')
        tags = request.POST.get('tags')
        datetime = request.POST.get('sch')
        data = Fbuser.objects.filter(user=request.user)
        context = {'data': data}
        for i in data:
            access_token=i.accesstoken
            page_id=str(i.page)
            app_id=i.app
            print(message)
            print(page_id)
            print(access_token)
            url = 'https://graph.facebook.com/' + page_id + '/feed'
            if request.method == 'POST':
                message = request.POST.get('message')
                # tags = request.POST.get('tags')
                parameter = {'message': message, 'access_token': access_token}
                r = requests.post(url=url, params=parameter)
                postid1 = r.json()
                postid2 = postid1['id']
                print(postid2)

                myArray = postid2.split("_")
                pageid = myArray[0]
                postid = myArray[1]
                result = Post.objects.create(user=request.user , pgid=pageid , ptid=postid)
                result.save()
                if len(postid1):
                    messages.info(request, 'successfully post')
                    return render(request, 'home.html')
                else:
                    messages.info(request, 'please try again')
                    return redirect('publish')
    else:
        return render(request, 'publish.html')

# def fbimg(request):
#     if request.POST:
#         data = Fbuser.objects.filter(user=request.user)
#         context = {'data': data}
#         for i in data:
#             access_token = i.accesstoken
#             page_id = str(i.page)
#             print(page_id)
#             print(access_token)
#             URL = 'https://graph.facebook.com/'+ page_id +'/photos? '
#             PARAMS = {'url': 'https://thedigischool.in/wp-content/uploads/2022/04/Digital-marketing-Bootcamp.png',
#                       'access_token': access_token}
#             r = requests.post(url=URL, params=PARAMS)
#             res = r.json()
#             print(res)
#             if len(res):
#                 messages.info(request, 'successfully post')
#                 return render(request, 'fbimg.html')
#
#             else:
#                 messages.error(request, 'please try again')
#     else:
#         return render(request, 'fbimg.html')

def fbimg(request):
    if request.method == 'POST':
        caps = request.POST.get('caption')
        img_url = request.POST.get('imgurl')
        schld = request.POST.get('schedule')
        submit =Facebookimg.objects.create(user=request.user, cap=caps, imgurl=img_url, scheduled=schld)
        submit.save()
        data = Fbuser.objects.filter(user=request.user)
        context = {'data': data}
        for i in data:
            access_token = i.accesstoken
            page_id = str(i.page)

        data1 = Facebookimg.objects.filter(user=request.user)
        context = {'data': data1}
        for i in data1:
            IMGURL = i.imgurl
            caps = i.cap
            SCHLD = i.scheduled
            print(IMGURL)
            print(SCHLD)
            URL = 'https://graph.facebook.com/'+ page_id + '/photos?'
            PARAMS = {'message':caps,'url':IMGURL,'access_token': access_token}
            r = requests.post(url=URL, params=PARAMS)
            res = r.json()
            print(res)
            if len(res):
                return render(request, 'home.html')
                # messages.info(request, 'successfully post')

            else:
                messages.info(request, 'please try again')
                return render(request, 'fbimg.html')

    else:
        return render(request, 'fbimg.html')

# def publish(request):
#     if request.method == 'POST':
#         access_token = request.POST.get('accesstoken')
#         URL = 'https://graph.facebook.com/100264182669977/feed'
#         PARAMS = {'message':'this  page is posting by Kajal', 'access_token':access_token}
#         r = requests.post(url=URL, params=PARAMS)
#         res = r.json()
#         print(res)
#         messages.info(request,'successfully post')
#         return render(request, 'login.html')

def fbvid(request):
    if request.method == 'POST':
        # caps = request.POST.get('capt')
        vidurl = request.POST.get('link')
        # submit = Fbuser.objects.create(user=request.user, cap=caps, imgurl=img_url)
        # submit.save()
        data = Fbuser.objects.filter(user=request.user)
        context = {'data': data}
        for i in data:
            access_token = i.accesstoken
            page_id = str(i.page)
            print(page_id)
            print(access_token)
            print(vidurl)
            URL = 'https://graph.facebook.com/'+page_id+'/videos?'
            PARAMS = {'access_token': access_token, 'file_url': vidurl}
            r = requests.post(url=URL, params=PARAMS)
            res = r.json()
            print(res)
            if len(res):
                return render(request, 'home.html')
                # messages.info(request, 'successfully post')

            else:
                messages.info(request, 'please try again')
                return render(request, 'fbvid.html')

    else:
        return render(request, 'fbvid.html')

def fblink(request):
    if request.method == 'POST':
        # caps = request.POST.get('capts')
        fb_link = request.POST.get('knot')
        # submit = Fbuser.objects.create(user=request.user, cap=caps, imgurl=img_url)
        # submit.save()
        data = Fbuser.objects.filter(user=request.user)
        context = {'data': data}
        for i in data:
            access_token = i.accesstoken
            page_id = str(i.page)
            print(page_id)
            print(access_token)
            print(fb_link)
            URL = 'https://graph.facebook.com/' + page_id + '/feed?'
            PARAMS = {'link': fb_link, 'access_token': access_token}
            r = requests.post(url=URL, params=PARAMS)
            res = r.json()
            print(res)
            if len(res):
                return render(request, 'home.html')
                # messages.info(request, 'successfully post')

            else:
                messages.info(request, 'please try again')
                return render(request, 'fblink.html')

    else:
        return render(request, 'fblink.html')

# def fbvid(request):
#     if request.POST:
#         vidurl= request.POST.get('link')
#         access_token='EAAHntjWIGC8BAKLlk0bxI1O8kNMCiebZAEx7gHA5Rdj41PZCvQyH1bwHC8nVCxjLiyZBw21EgFPlSachz7fprk2TH0DFN6Mqw3ZAZCq8UjIhvBJOdVzNMP3QdZBgeZCw0uGKZBUmvmEnU2N6tT77VvxePmuY2TCuZBpL1RDDBA6URVorKWthTPunbQtm9RFLRWrQYnpP6rMEWsGgZCwj1RIbSz'
#         URL = 'https://graph.facebook.com/100264182669977/videos? '
#         PARAMS = {'file_url': vidurl , 'access_token':access_token}
#         r = requests.post(url=URL, params=PARAMS)
#         res = r.json()
#         print(res)
#         if len(res):
#             messages.info(request, 'successfully post')
#             return render(request, 'fbvid.html')
#
#         else:
#             messages.error(request, 'please try again')
#     else:
#         return render(request, 'fbvid.html')

def igimg(request):
    if request.POST:
        img_url =  request.POST.get('igimg')
        titl= request.POST.get('title')
        print(img_url)
        print(titl)
        data = Fbuser.objects.filter(user=request.user)
        context = {'data': data}
        for i in data:
            access_token = i.accesstoken
            page_id = str(i.page)
            print(page_id)
            print(access_token)
            URL = 'https://graph.facebook.com/v13.0/'+ page_id +'?fields=instagram_business_account'
            PARAMS = { 'access_token': access_token}
            r = requests.get(url=URL, params=PARAMS)
            ig_user_id= r.json()
            print(ig_user_id)
            ig_user_id1 = ig_user_id['instagram_business_account']
            print(ig_user_id1)
            ig_user_id2 = ig_user_id1['id']
            print(ig_user_id2)
            URL1 = 'https://graph.facebook.com/v13.0/'+ig_user_id2+'/media?'
            PARAMETER1 = {'image_url': img_url,'caption': titl , 'access_token': access_token}
            r = requests.post(url=URL1, params=PARAMETER1)
            container_id = r.json()
            print(container_id)
            creation_id = container_id['id']
            URL2 = 'https://graph.facebook.com/v13.0/'+ig_user_id2+'/media_publish?creation_id='+creation_id
            PARAMS = {'access_token': access_token}
            r = requests.post(url=URL2, params=PARAMS)
            ig_post_id = r.json()
            print(ig_post_id)

            if len(ig_post_id):
                return render(request, 'home.html')
                # messages.info(request, 'successfully post')

            else:
                messages.info(request, 'please try again')
                return render(request, 'igimg.html')

    else:
        return render(request, 'igimg.html')

def igvid(request):
    if request.POST:
        vid_url =  request.POST.get('vidurl')
        vid_caption= request.POST.get('vidcap')
        data = Fbuser.objects.filter(user=request.user)
        context = {'data': data}
        for i in data:
            access_token = i.accesstoken
            page_id = str(i.page)
            print(page_id)
            print(access_token)
            URL = 'https://graph.facebook.com/v13.0/'+ page_id +'?fields=instagram_business_account'
            PARAMS = {'access_token': access_token}
            r = requests.get(url=URL, params=PARAMS)
            ig_user_id= r.json()
            print(ig_user_id)
            ig_user_id1 = ig_user_id['instagram_business_account']
            print(ig_user_id1)
            ig_user_id2 = ig_user_id1['id']
            print(ig_user_id2)
            URL1 = 'https://graph.facebook.com/v13.0/'+ig_user_id2+'/media?'
            PARAMETER1 = {'video_url': vid_url, 'caption': vid_caption, 'media_type': 'VIDEO', 'access_token':access_token}
            r = requests.post(url=URL1, params=PARAMETER1)
            container_id = r.json()
            print(container_id)
            creation_id1 = container_id['id']
            print(creation_id1)
            url1 = 'https://graph.facebook.com/'+creation_id1+'?fields=status_code&access_token='+access_token
            r = requests.get(url=url1)
            res = r.json()
            print(res)
            res1 = res['status_code']
            print(res1)
            for i in res1:
                url1 = 'https://graph.facebook.com/' + creation_id1 + '?fields=status_code&access_token=' + access_token
                r = requests.get(url=url1)
                res = r.json()
                print(res)
                res1 = res['status_code']
                if res1 == 'FINISHED':
                    URL2 = 'https://graph.facebook.com/v13.0/'+ig_user_id2+'/media_publish?'
                    PARAMS = {'creation_id':creation_id1,'access_token': access_token}
                    r = requests.post(url=URL2, params=PARAMS)
                    ig_post_id = r.json()
                    print(ig_post_id)

                    if len(ig_post_id):
                        return render(request, 'home.html')
                        # messages.info(request, 'successfully post')

                    else:
                        messages.info(request, 'please try again')
                        return render(request, 'igvid.html')

                else:
                    time.sleep(10)
                    continue
    else:
        return render(request, 'igvid.html')



def logout(request):
    auth.logout(request)
    return redirect('/')

