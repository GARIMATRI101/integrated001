from .import views
from django.urls import path

urlpatterns = [
        # path('', views.index, name='home'),
        path('apphome/', views.apphome, name='apphome'),
        path('login/', views.login, name='login'),
        path('signup/', views.signup, name='signup'),
        path('fbconnect/', views.fbconnect, name='fbconnect'),
        path('publish/', views.publish, name='publish'),
        path('fbimg/', views.fbimg, name='fbimg'),
        path('logout/', views.logout, name='logout'),
        path('home/', views.home, name='home1'),
        path('fbvid/', views.fbvid, name='fbvid'),
        path('fblink/', views.fblink, name='fblink'),
        path('igimg/', views.igimg, name='igimg'),
        path('igvid/', views.igvid, name='igvid'),


]